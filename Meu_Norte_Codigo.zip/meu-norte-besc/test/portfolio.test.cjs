const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const C=require('../public/stock-core.js');
const p={ticker:'ITUB4',name:'Itaú',category:'B',quantity:10,average:20,quote:null,quotedAt:null,source:'manual'};
test('compra ponderada inclui taxas',()=>{
 const next=C.addPurchase(p,{...p,quantity:10,price:30,fees:10});
 assert.equal(next.quantity,20);assert.equal(next.average,25.5);
 assert.equal(C.summary([next]).invested,510);
});
test('cotação ausente não vira zero e categorias somam custo',()=>{
 const s=C.summary([p,{...p,ticker:'VALE3',category:'C',quote:25}]);
 assert.equal(s.invested,400);assert.equal(s.market,250);assert.equal(s.result,null);
 assert.equal(s.groups.B+s.groups.C,400);
 const z=C.summary([{...p,quote:0}]);assert.equal(z.result,-200);assert.equal(z.complete,true);
});
test('backup rejeita duplicatas e números inválidos',()=>{
 const b={...C.fresh(),positions:[p]};assert.deepEqual(C.validate(b),b);
 for(const mod of [{quantity:-1},{quantity:1.5},{average:Infinity},{category:'X'},{quote:NaN}])assert.throws(()=>C.validate({...b,positions:[{...p,...mod}]}));
 assert.throws(()=>C.validate({...b,positions:[p,p]}));
});
test('API exige ticker correto, reais e horário',()=>{
 const r={symbol:'ITUB4',data:{currency:'BRL',regularMarketPrice:30,regularMarketTime:'2026-10-26T18:00:00Z'}};
 assert.equal(C.parseQuote(r,'ITUB4').quote,30);
 assert.throws(()=>C.parseQuote({...r,changed:true},'ITUB4'));
 assert.throws(()=>C.parseQuote(r,'VALE3'));
 assert.throws(()=>C.parseQuote({...r,data:{...r.data,currency:'USD'}},'ITUB4'));
});
test('HTML portátil contém scripts e IDs únicos',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../public/Meu_Norte_Investimentos.html'),'utf8');
 assert.ok(!/<script src=|<link rel="stylesheet"/.test(html));
 const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);
 // Apenas marcação estática: trechos de templates JS podem gerar IDs em runtime.
 const markup=html.split('<script')[0];
 const staticIds=[...markup.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);
 assert.equal(new Set(staticIds).size,staticIds.length);
 for(const id of ['stock-nav','stocks-state','stock-dialog','stock-rows'])assert.ok(ids.includes(id),id);
});
test('servidor bloqueia origem externa, arquivos privados e ticker inválido',async()=>{
 const {server}=require('../server.cjs');
 function request(url,headers={}){return new Promise(resolve=>{
  let status;server.emit('request',{url,method:'GET',headers:{host:'localhost:3000',...headers}},{writeHead(code){status=code},end(body){resolve({status,body:String(body||'')})}});
 });}
 assert.equal((await request('/.env')).status,404);
 assert.equal((await request('/api/quotes?symbols=INVALID')).status,400);
 assert.equal((await request('/api/status',{origin:'https://example.com'})).status,403);
 assert.equal((await request('/api/status')).status,200);
 assert.equal((await request('/')).status,200);
});

const {test}=require('node:test'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
test('scripts integrados iniciam, registram compra e exportam backup',()=>{
 const nodes=new Map(),saved=new Map();
 function node(id){if(!nodes.has(id))nodes.set(id,{textContent:['initial-state','stocks-state'].includes(id)?'null':'',innerHTML:'',value:'',dataset:{},style:{},classList:{add(){},remove(){},toggle(){},contains(){return false}},setAttribute(){},removeAttribute(){},addEventListener(name,fn){this[name]=fn},showModal(){this.open=true},close(){this.open=false},scrollIntoView(){},reset(){},reportValidity(){return true},elements:{namedItem:key=>node(id+'-'+key)}});return nodes.get(id);}
 const ctx=vm.createContext({console,Intl,Date,Math,JSON,Set,Number,String,Error,SyntaxError,structuredClone,setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,Blob,URL,location:{protocol:'file:'},localStorage:{getItem:k=>saved.get(k)||null,setItem:(k,v)=>saved.set(k,v)},document:{getElementById:node,documentElement:{dataset:{}},querySelectorAll:()=>[],addEventListener(){}}});
 vm.runInContext('window=globalThis;window.addEventListener=()=>{}',ctx);
 for(const file of ['stock-core.js','base.js','stocks.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'../public',file),'utf8'),ctx);
 assert.ok(node('stock-rows').innerHTML.includes('primeira compra'));
 const values={ticker:'ITUB4',name:'Itaú',category:'B',quantity:'10',price:'20',fees:'5',quote:'25'};
 for(const [k,v]of Object.entries(values))node('stock-form-'+k).value=v;
 node('stock-form').onsubmit({preventDefault(){}});
 const data=JSON.parse(saved.get('meu-norte-carteira-v1-stocks-v1'));
 assert.equal(data.positions[0].average,20.5);
 assert.ok(node('stock-rows').innerHTML.includes('ITUB4'));
 assert.equal((node('stock-segments').innerHTML.match(/<circle/g)||[]).length,1);
 vm.runInContext('download=(content)=>globalThis.exported=content',ctx);node('export-json').onclick();
 const backup=JSON.parse(ctx.exported);assert.equal(backup.items.length,6);assert.equal(backup.stocks.positions[0].quantity,10);
});

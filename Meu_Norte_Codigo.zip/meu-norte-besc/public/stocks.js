/* Extensão da carteira original. Não acessa a conta da corretora. */
(() => {
  'use strict';
  const C = window.StockCore;
  const stockKey = KEY + '-stocks-v1';
  const byId = id => document.getElementById(id);
  const currency = n => new Intl.NumberFormat('pt-BR', {style:'currency',currency:'BRL'}).format(n);
  const priceFormat = n => new Intl.NumberFormat('pt-BR', {style:'currency',currency:'BRL',maximumFractionDigits:6}).format(n);
  const pc = n => new Intl.NumberFormat('pt-BR',{maximumFractionDigits:2}).format(n)+'%';
  const day = () => new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo'}).format(new Date());
  const time = value => value ? new Date(value).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'}) : 'Sem horário';
  const trend = n => n>0?'stock-gain':n<0?'stock-loss':'stock-neutral';
  let book = C.fresh(), editTicker = null, busy = false, service = false, startupError = '';
  try {
    const saved=localStorage.getItem(stockKey), embedded=JSON.parse(byId('stocks-state').textContent);
    book=C.validate(saved?JSON.parse(saved):embedded||C.fresh());
  } catch {
    startupError='Não foi possível ler o registro de ações. Importe um backup antes de fazer novas alterações.';
  }
  function message(text,error=false){byId('stock-message').textContent=text;byId('stock-message').classList.toggle('error',error);}
  function baseRow(){return state.items.find(x=>x.id==='acoes-br');}
  function syncBase(){
    if(!book.linked)return;
    let row=baseRow();
    if(!row){row=structuredClone(INITIAL.find(x=>x.id==='acoes-br'));state.items.push(row);}
    row.amount=Math.round(C.summary(book.positions).invested*100)/100;
  }
  const originalRender=render;
  render=function(){
    syncBase();originalRender();
    const field=byId('amount-acoes-br');
    if(field&&book.linked){field.readOnly=true;field.title='Calculado na aba Ações — B3. Desative o vínculo para editar manualmente.';}
  };
  const originalOpenEdit=openEdit;
  openEdit=function(id=null){originalOpenEdit(id);const f=byId('investment-form');f.elements.namedItem('amount').readOnly=id==='acoes-br'&&book.linked;};
  const originalDelete=byId('delete-button').onclick;
  byId('delete-button').onclick=()=>{if(editing==='acoes-br'&&book.linked)return notify('Desative o vínculo na aba Ações antes de excluir este resumo.');originalDelete();};
  function saveBook(){
    book=C.validate(book);syncBase();
    try{localStorage.setItem(stockKey,JSON.stringify(book));startupError='';}
    catch{message('Não foi possível salvar as ações no navegador. Exporte o backup JSON antes de fechar.',true);}
    persist();render();drawStocks();
  }
  function showStocks(){
    document.querySelectorAll('.section').forEach(el=>el.classList.toggle('active',el.id==='stocks'));
    document.querySelectorAll('nav button').forEach(el=>{el.classList.remove('active');el.removeAttribute('aria-current');});
    byId('stock-nav').classList.add('active');byId('stock-nav').setAttribute('aria-current','page');
    byId('page-title').textContent='Minhas ações';
    byId('page-subtitle').textContent='Preço médio, patrimônio e distribuição BESC em um só lugar.';
    byId('add-button').textContent='＋ Registrar compra';drawStocks();
  }
  const originalShowPage=showPage;
  showPage=function(page){byId('stock-nav').classList.remove('active');byId('stock-nav').removeAttribute('aria-current');byId('add-button').textContent='＋ Novo investimento';originalShowPage(page);};
  const originalAdd=byId('add-button').onclick;
  byId('add-button').onclick=()=>byId('stocks').classList.contains('active')?openPosition():originalAdd();
  byId('stock-nav').onclick=showStocks;
  function drawStocks(){
    const s=C.summary(book.positions);
    byId('stock-invested').textContent=currency(s.invested);
    byId('stock-market').textContent=!book.positions.length?currency(0):s.quoted?currency(s.market):'—';
    byId('stock-coverage').textContent=!book.positions.length?'Adicione sua primeira posição':s.complete?'Todas as posições têm cotação; confira os horários':`Subtotal parcial: ${s.quoted} de ${book.positions.length} posições com cotação`;
    byId('stock-result').textContent=s.result===null?'—':currency(s.result);
    byId('stock-result').className=s.result===null?'':trend(s.result);
    byId('stock-return').textContent=s.returnPercent===null?'Resultado indisponível sem todas as cotações':pc(s.returnPercent)+' sobre o custo · sem proventos e impostos';
    byId('stock-count').textContent=book.positions.length+' ativos';byId('stock-table-count').textContent=book.positions.length+' posições';
    byId('stock-chart-total').textContent=currency(s.invested);
    const circumference=2*Math.PI*96;let offset=0;
    byId('stock-segments').innerHTML=Object.entries(s.groups).filter(([,v])=>v>0).map(([k,v])=>{
      const length=v/s.invested*circumference, category=C.categories[k];
      const piece=`<circle cx="120" cy="120" r="96" fill="none" stroke="${category.color}" stroke-width="28" stroke-dasharray="${length} ${circumference-length}" stroke-dashoffset="${-offset}"><title>${category.name}: ${currency(v)} (${pc(v/s.invested*100)})</title></circle>`;
      offset+=length;return piece;
    }).join('');
    byId('stock-legend').innerHTML=Object.entries(C.categories).filter(([k])=>k!=='O'||s.groups.O>0).map(([k,c])=>`<div class="besc-row"><span class="dot" style="background:${c.color}"></span><span>${c.name}</span><b>${pc(s.invested?s.groups[k]/s.invested*100:0)}</b><small>${currency(s.groups[k])}</small></div>`).join('');
    byId('stock-auto').checked=book.auto;byId('stock-link').checked=book.linked;
    byId('stock-link-note').textContent=book.linked?'Ações BR no resumo é calculado por esta aba. O valor manual anterior será restaurado se você desativar.':'O total manual em Minha carteira é independente. Ative para usar este detalhamento sem somar o mesmo dinheiro duas vezes.';
    drawRows();
  }
  function drawRows(){
    const search=byId('stock-search').value.trim().toLowerCase(), category=byId('stock-filter').value;
    const rows=book.positions.filter(p=>(!category||p.category===category)&&(!search||(p.ticker+' '+p.name).toLowerCase().includes(search)));
    byId('stock-rows').innerHTML=rows.length?rows.map(p=>{
      const cost=p.quantity*p.average, value=p.quote===null?null:p.quantity*p.quote, result=value===null?null:value-cost, c=C.categories[p.category];
      const status=p.quote===null?'Sem cotação':(p.source==='brapi'?'brapi · cotação de ':'Manual · informado em ')+time(p.quotedAt);
      const old=p.quotedAt&&new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo'}).format(new Date(p.quotedAt))!==day();
      return `<tr><td><span class="stock-symbol">${p.ticker}</span><small>${esc(p.name)}</small><span class="stock-badge" style="color:${c.color};background:${c.color}15">${c.name}</span></td><td>${p.quantity.toLocaleString('pt-BR')}</td><td>${priceFormat(p.average)}</td><td>${currency(cost)}</td><td>${p.quote===null?'—':priceFormat(p.quote)}<small>${esc(status)}</small>${old?'<small>Data anterior a hoje</small>':''}</td><td>${value===null?'—':currency(value)}</td><td class="${result===null?'':trend(result)}">${result===null?'—':currency(result)}<small class="${result===null?'':trend(result)}">${result!==null&&cost>0?pc(result/cost*100):'—'}</small></td><td><button class="edit-btn" data-stock-edit="${p.ticker}">Editar posição</button></td></tr>`;
    }).join(''):`<tr><td colspan="8" class="stock-empty"><strong>${book.positions.length?'Nenhuma posição neste filtro':'Sua carteira de ações começa aqui'}</strong>${book.positions.length?'Tente outro ticker ou setor.':'Registre a primeira compra. O gráfico se preenche com os valores que você informar.'}</td></tr>`;
  }
  byId('stock-search').oninput=drawRows;byId('stock-filter').onchange=drawRows;
  byId('stock-rows').onclick=e=>{const button=e.target.closest('[data-stock-edit]');if(button)openPosition(button.dataset.stockEdit);};
  byId('stock-tickers').innerHTML=C.catalog.map(([ticker,name])=>`<option value="${ticker}">${name}</option>`).join('');
  const form=byId('stock-form'), field=name=>form.elements.namedItem(name);
  function openPosition(ticker=null){
    editTicker=ticker;form.reset();field('ticker').readOnly=!!ticker;byId('stock-fees-label').classList.toggle('hidden',!!ticker);field('fees').value=0;
    byId('stock-remove').classList.toggle('hidden',!ticker);byId('stock-form-title').textContent=ticker?'Editar posição':'Registrar compra';
    byId('stock-price-label').textContent=ticker?'Preço médio da posição (R$)':'Preço pago por ação (R$)';
    byId('stock-form-help').textContent=ticker?'Edite a posição total atual. Para adicionar uma compra, use “Registrar compra”.':'Uma nova compra do mesmo ticker soma a quantidade e recalcula o preço médio ponderado.';
    if(ticker){const p=book.positions.find(p=>p.ticker===ticker);for(const k of ['ticker','name','category','quantity'])field(k).value=p[k];field('price').value=Number(p.average.toFixed(6));field('quote').value=p.quote??'';}
    byId('stock-dialog').showModal();
  }
  field('ticker').oninput=()=>{field('ticker').value=field('ticker').value.toUpperCase();const match=C.catalog.find(x=>x[0]===field('ticker').value);const existing=book.positions.find(x=>x.ticker===field('ticker').value);if(existing){field('name').value=existing.name;field('category').value=existing.category;}else if(match){field('name').value=match[1];field('category').value=match[2];}};
  byId('stock-add').onclick=()=>openPosition();byId('stock-close').onclick=byId('stock-cancel').onclick=()=>byId('stock-dialog').close();
  form.onsubmit=e=>{
    e.preventDefault();if(!form.reportValidity())return;
    const ticker=field('ticker').value.trim().toUpperCase(), old=book.positions.find(p=>p.ticker===ticker), name=field('name').value.trim();
    if(!name)return notify('Informe o nome da empresa.');
    const purchase={ticker,name,category:field('category').value,quantity:Number(field('quantity').value),price:Number(field('price').value),fees:editTicker?0:Number(field('fees').value)};
    let next=editTicker?{...old,name,category:purchase.category,quantity:purchase.quantity,average:purchase.price}:C.addPurchase(old,purchase);
    const quote=field('quote').value===''?null:Number(field('quote').value);
    if(editTicker){if(quote!==old.quote)next={...next,quote,quotedAt:quote===null?null:new Date().toISOString(),source:'manual'};}
    else if(quote!==null)next={...next,quote,quotedAt:new Date().toISOString(),source:'manual'};
    try{book=C.validate({...book,positions:old?book.positions.map(p=>p.ticker===ticker?next:p):[...book.positions,next]});saveBook();byId('stock-dialog').close();notify(editTicker?'Posição atualizada.':'Compra registrada; preço médio recalculado.');}
    catch(error){notify(error.message);}
  };
  byId('stock-remove').onclick=()=>{const ticker=editTicker;confirmWith('Excluir posição?','A posição de '+ticker+' será removida deste controle. Isso não vende ações na corretora.',()=>{book.positions=book.positions.filter(p=>p.ticker!==ticker);saveBook();byId('stock-dialog').close();notify('Posição excluída.');});};
  byId('stock-link').onchange=e=>{
    if(e.target.checked){e.target.checked=false;confirmWith('Vincular Ações BR ao detalhamento?',`O resumo passará de ${currency(baseRow()?.amount||0)} para ${currency(C.summary(book.positions).invested)}. O valor manual anterior ficará guardado para restaurar ao desativar.`,()=>{book.previousManual=baseRow()?.amount||0;book.linked=true;saveBook();});}
    else {book.linked=false;if(baseRow())baseRow().amount=book.previousManual??0;book.previousManual=null;saveBook();}
  };
  byId('stock-auto').onchange=()=>{book.auto=byId('stock-auto').checked;saveBook();if(book.auto)maybeRefresh();};
  async function getJSON(url){const response=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('Falha na consulta (HTTP '+response.status+').');return response.json();}
  async function refreshQuotes(){
    if(busy)return;if(!book.positions.length)return message('Cadastre uma posição antes de consultar cotações.');
    busy=true;byId('stock-refresh').disabled=true;book.lastAttempt=day();saveBook();
    const symbols=book.positions.map(p=>p.ticker), errors=[];let success=0;
    try{for(const ticker of symbols){
      message('Consultando '+ticker+'… '+success+' atualizada(s).');
      try{
        let quote;
        if(service){const data=await getJSON('/api/quotes?symbols='+encodeURIComponent(ticker));if(!data.results?.length)throw Error(data.errors?.[0]?.message||'Sem cotação retornada.');quote=data.results[0];}
        else{if(!['PETR4','VALE3','ITUB4','MGLU3'].includes(ticker))throw Error('Exige servidor local com chave brapi.');const data=await getJSON('https://brapi.dev/api/v2/stocks/quote?symbols='+ticker);quote=C.parseQuote(data.results?.find(r=>(r.requestedSymbol||r.symbol)===ticker),ticker);}
        const p=book.positions.find(p=>p.ticker===ticker);if(p){const candidate={...p,quote:quote.quote,quotedAt:quote.quotedAt,source:'brapi'};C.validate({...book,positions:book.positions.map(x=>x.ticker===ticker?candidate:x)});Object.assign(p,candidate);success++;}
      }catch(error){errors.push(ticker+': '+(error.name==='TimeoutError'?'Tempo de consulta excedido.':error.message));}
    }
    saveBook();message(success+' cotação(ões) atualizada(s).'+(errors.length?'\n'+errors.join('\n'):' Confira a data e hora de cada preço.'),errors.length>0);
    }finally{busy=false;byId('stock-refresh').disabled=false;}
  }
  function maybeRefresh(){if(book.auto&&book.positions.length&&book.lastAttempt!==day()&&!document.hidden)refreshQuotes();}
  byId('stock-refresh').onclick=refreshQuotes;
  document.addEventListener('visibilitychange',maybeRefresh);window.addEventListener('online',maybeRefresh);setInterval(maybeRefresh,60000);
  // Um backup completo preserva tanto o guia original quanto as ações.
  byId('export-json').onclick=()=>download(JSON.stringify({...state,stocks:book},null,2),'application/json','minha-carteira-completa.json');
  byId('import-file').onchange=async e=>{
    const file=e.target.files[0];if(!file)return;
    try{if(file.size>4000000)throw Error('Backup deve ter até 4 MB.');const raw=JSON.parse(await file.text()), next=validate(raw), hasStocks=Object.hasOwn(raw,'stocks'), nextStocks=hasStocks?C.validate(raw.stocks):C.fresh();
      confirmWith('Importar carteira?',hasStocks?'O guia e as posições em ações serão substituídos pelos dados deste backup.':'Este backup antigo substitui o guia. Suas posições em ações serão mantidas e o vínculo com o resumo será desativado.',()=>{
        state=next;if(hasStocks)book=nextStocks;else{book.linked=false;book.previousManual=null;}saveBook();notify('Backup importado.');
      });
    }catch(error){notify(error instanceof SyntaxError?'JSON inválido. Selecione um backup exportado pelo painel.':error.message);}finally{e.target.value='';}
  };
  byId('stock-csv').onclick=()=>{
    const cell=v=>'"'+String(v??'').replace(/^[=+@\-\t\r\n]/,"'$&").replace(/"/g,'""')+'"';
    const num=n=>n===null?'':String(n).replace('.',',');
    const rows=[['Ticker','Empresa','Categoria BESC','Quantidade','Preço médio BRL','Investido BRL','Cotação BRL','Valor da posição BRL','Data da cotação','Fonte'],...book.positions.map(p=>[p.ticker,p.name,C.categories[p.category].name,p.quantity,num(p.average),num(p.quantity*p.average),num(p.quote),num(p.quote===null?null:p.quantity*p.quote),p.quotedAt,p.source])];
    download('\ufeff'+rows.map(r=>r.map(cell).join(';')).join('\r\n'),'text/csv;charset=utf-8','minhas-acoes.csv');
  };
  byId('export-html').onclick=()=>{
    const template=byId('portable-template');let clone;
    if(template){const bytes=Uint8Array.from(atob(template.textContent.trim()),c=>c.charCodeAt(0));clone=new DOMParser().parseFromString(new TextDecoder().decode(bytes),'text/html').documentElement;}
    else clone=document.documentElement.cloneNode(true);
    clone.dataset.instance='-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
    clone.querySelector('#initial-state').textContent=JSON.stringify(state).replace(/</g,'\\u003c');
    clone.querySelector('#stocks-state').textContent=JSON.stringify(book).replace(/</g,'\\u003c');
    clone.querySelectorAll('dialog').forEach(d=>d.removeAttribute('open'));clone.querySelector('#toast').textContent='';
    clone.querySelector('#transfer-panel').classList.add('hidden');clone.querySelectorAll('input').forEach(input=>input.removeAttribute('value'));
    download('<!doctype html>\n'+clone.outerHTML,'text/html;charset=utf-8','Meu_Norte_Investimentos.html');notify('Painel portátil exportado com seus dados.');
  };
  render();drawStocks();if(startupError)message(startupError,true);
  async function initializeQuotes(){
    if(location.protocol!=='file:'){try{const status=await getJSON('/api/status');service=status.service==='meu-norte';byId('stock-service').textContent=service?(status.configured?'Servidor local conectado à brapi. A cobertura depende do seu plano.':'Servidor local sem chave. Apenas PETR4, VALE3, ITUB4 e MGLU3 estão disponíveis para teste.'):'Use o servidor incluído para consultar outros ativos.';}catch{byId('stock-service').textContent='Servidor de cotações não detectado. Inicie com npm.cmd start. Testes públicos limitados a PETR4, VALE3, ITUB4 e MGLU3.';}}
    else byId('stock-service').textContent='Modo arquivo: cotações manuais e teste público de PETR4, VALE3, ITUB4 e MGLU3. Para outros ativos, use o servidor local com sua chave brapi.';
    maybeRefresh();
  }
  initializeQuotes();
})();

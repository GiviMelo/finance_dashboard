/* Cálculos e validação compartilhados pelo navegador e pelos testes. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.StockCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const categories = {
    B: { name: 'Bancos', color: '#397ee8' },
    E: { name: 'Energia elétrica', color: '#e5ad37' },
    S: { name: 'Seguros', color: '#9565d5' },
    C: { name: 'Commodities', color: '#23a38b' },
    O: { name: 'Outros setores', color: '#8c98ab' }
  };
  const catalog = [
    ['BBAS3','Banco do Brasil','B'],['ITUB4','Itaú Unibanco','B'],
    ['BBDC3','Bradesco ON','B'],['BBDC4','Bradesco PN','B'],
    ['ABCB4','ABC Brasil','B'],['BMGB4','Banco BMG','B'],
    ['BPAC11','BTG Pactual','B'],['SANB11','Santander Brasil','B'],
    ['CMIG4','Cemig','E'],['TAEE11','Taesa','E'],['ISAE4','ISA Energia Brasil','E'],
    ['EGIE3','Engie Brasil','E'],['CPLE3','Copel','E'],
    ['BBSE3','BB Seguridade','S'],['CXSE3','Caixa Seguridade','S'],
    ['PSSA3','Porto','S'],['WIZC3','Wiz (corretagem)','S'],['IRBR3','IRB Brasil RE (resseguro)','S'],
    ['PETR4','Petrobras PN','C'],['PETR3','Petrobras ON','C'],['VALE3','Vale','C'],
    ['KLBN11','Klabin','C'],['GOAU4','Metalúrgica Gerdau','C'],['CMIN3','CSN Mineração','C'],
    ['SUZB3','Suzano','C'],['GGBR4','Gerdau','C'],['PRIO3','PRIO','C'],
    ['MGLU3','Magazine Luiza','O']
  ];
  const fresh = () => ({ version: 1, positions: [], auto: false, lastAttempt: '', linked: false, previousManual: null });
  const round = n => Math.round((n + Number.EPSILON) * 1e8) / 1e8;
  function validNumber(n,min,max){return typeof n==='number'&&Number.isFinite(n)&&n>=min&&n<=max;}
  function validate(data) {
    if (!data || data.version !== 1 || !Array.isArray(data.positions) || data.positions.length > 200) throw Error('Backup de ações inválido.');
    const ids = new Set();
    const positions = data.positions.map(p => {
      if(!p || typeof p.ticker!=='string' || !/^[A-Z]{4}\d{1,2}$/.test(p.ticker) || ids.has(p.ticker)) throw Error('Ticker inválido ou repetido no backup.');
      ids.add(p.ticker);
      if(typeof p.name!=='string'||p.name.length>100||!Object.hasOwn(categories,p.category)||!validNumber(p.quantity,1,1e9)||!Number.isInteger(p.quantity)||!validNumber(p.average,0,1e9)||p.quantity*p.average>1e12) throw Error('Posição inválida: confira quantidade, preço médio e categoria.');
      if(p.quote!==null&&!validNumber(p.quote,0,1e9))throw Error('Cotação inválida.');
      if(p.quotedAt!==null&&(typeof p.quotedAt!=='string'||!Number.isFinite(Date.parse(p.quotedAt))))throw Error('Data da cotação inválida.');
      return {ticker:p.ticker,name:p.name.trim()||p.ticker,category:p.category,quantity:p.quantity,average:p.average,quote:p.quote,quotedAt:p.quotedAt,source:p.source==='brapi'?'brapi':'manual'};
    });
    return {version:1,positions,auto:data.auto===true,lastAttempt:typeof data.lastAttempt==='string'?data.lastAttempt.slice(0,10):'',linked:data.linked===true,previousManual:validNumber(data.previousManual,0,1e12)?data.previousManual:null};
  }
  function addPurchase(old, purchase) {
    const quantity=(old?.quantity||0)+purchase.quantity;
    const cost=(old?old.quantity*old.average:0)+purchase.quantity*purchase.price+purchase.fees;
    return {...old,ticker:purchase.ticker,name:purchase.name,category:purchase.category,quantity,average:round(cost/quantity),quote:old?.quote??null,quotedAt:old?.quotedAt??null,source:old?.source||'manual'};
  }
  function summary(positions) {
    let invested=0,market=0,quoted=0;
    const groups=Object.fromEntries(Object.keys(categories).map(k=>[k,0]));
    for(const p of positions){const cost=p.quantity*p.average;invested+=cost;groups[p.category]+=cost;if(p.quote!==null){market+=p.quantity*p.quote;quoted++;}}
    const complete=quoted===positions.length;
    return {invested,market,quoted,complete,groups,result:complete?market-invested:null,returnPercent:complete&&invested>0?(market/invested-1)*100:null};
  }
  function parseQuote(result,ticker){
    if(!result||result.changed===true||result.symbol!==ticker)throw Error('Ticker alterado pelo provedor. Revise a posição antes de atualizar.');
    const d=result.data;
    if(!d||d.currency!=='BRL'||!validNumber(d.regularMarketPrice,0,1e9)||!d.regularMarketTime)throw Error('Cotação sem preço, moeda ou horário válido.');
    const date=typeof d.regularMarketTime==='number'?new Date(d.regularMarketTime*1000):new Date(d.regularMarketTime);
    if(!Number.isFinite(date.getTime())||date.getTime()>Date.now()+86400000)throw Error('Horário da cotação inválido.');
    return {quote:d.regularMarketPrice,quotedAt:date.toISOString(),source:'brapi'};
  }
  return {categories,catalog,fresh,validate,addPurchase,summary,parseQuote};
});

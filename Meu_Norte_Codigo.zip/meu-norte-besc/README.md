# Meu Norte — carteira e ações B3

Projeto em HTML, CSS e JavaScript, com servidor Node.js sem dependências externas.

## Abrir no VS Code

1. Extraia o ZIP e abra a pasta do projeto no VS Code.
2. Instale Node.js 22 ou superior, caso ainda não tenha.
3. No terminal dessa pasta, execute `npm.cmd start` (no macOS/Linux: `npm start`).
4. Abra http://localhost:3000 no navegador. Mantenha o terminal aberto.

Não precisa executar npm install. Para encerrar, pressione Ctrl+C no terminal.

## Cotações

O preço médio é o custo das suas compras; a cotação é o preço de mercado. Uma nova compra recalcula o preço médio ponderado, incluindo as taxas informadas. O gráfico BESC usa quantidade × preço médio, isto é, o capital aplicado.

Sem chave, a API brapi permite os ativos de demonstração PETR4, VALE3, ITUB4 e MGLU3. Para consultar outros ativos, obtenha sua própria chave e confira os limites e a cobertura do plano em https://brapi.dev/docs/acoes/cotacao.

Copie `.env.example` para `.env`, preencha `BRAPI_API_KEY=sua_chave` e reinicie o servidor. A chave fica no servidor local. Nunca compartilhe o arquivo .env. Não coloque a chave no HTML.

Ative a opção de atualização diária na aba Ações. A consulta ocorre ao abrir a página e quando ela permanece aberta, uma vez por dia no horário de São Paulo. O computador, o servidor e a página precisam estar ativos. Não há execução com o computador desligado. O botão Atualizar permite nova consulta; o servidor reutiliza respostas por até 15 minutos. São exibidos data e horário fornecidos pela API; pregões fechados, atrasos e limites do provedor podem manter a última cotação disponível. Erros não apagam a cotação anterior.

Sem API, você também pode preencher a cotação manualmente. Carteiras parcialmente cotadas mostram um subtotal e não exibem um resultado total enganoso.

## Usar apenas o HTML

Abra `public/Meu_Norte_Investimentos.html` diretamente no navegador. Cadastro, edição, gráficos, guias e backups funcionam sem servidor. Consultas de demonstração dependem da internet e de o navegador/provedor permitir a requisição; demais cotações exigem o servidor configurado ou preenchimento manual.

## Dados e backups

Os dados são salvos no localStorage do navegador e não são enviados a uma conta. Abrir em outro navegador, mudar o endereço ou mover o HTML pode mudar o local de armazenamento. Limpar dados do navegador ou usar modo privado pode apagar os registros. Exporte regularmente o Backup completo JSON pelo botão de exportação. Importe o JSON para transferir a carteira entre o HTML e o servidor.

A opção de vincular Ações BR à visão geral substitui o valor manual dessa modalidade pela soma das posições. Ao desvincular, o valor manual anterior é restaurado. Não ative se esse valor manual incluir ações ainda não cadastradas. As demais modalidades e planos permanecem editáveis. Backups antigos continuam aceitos.

## Organização

- Bancos, Energia elétrica, Seguros e Commodities formam o gráfico BESC. Outros setores têm a categoria Outros para não distorcer a distribuição.
- A lista de referência retrata o ranking de usuários do Investidor10 consultado em 27/10/2026, sem afirmar representar todos os investidores da B3. Em seguros foram confirmadas apenas quatro empresas; IRBR3 é alternativa setorial, sem posição de quinto lugar comprovada. Fontes estão na aba.
- Não há conexão com corretoras, envio de ordens ou recomendações de investimento. Vendas, desdobramentos, bonificações e mudanças de ticker exigem ajuste manual da posição. Resultado representa apenas variação do preço; não inclui proventos, impostos ou taxas futuras.

## Código

`public/base.js` mantém a carteira e os guias; `public/stocks.js` controla a aba de ações; `public/stock-core.js` valida dados e calcula posições; `server.cjs` consulta a API sem expor a chave. CSS fica em `public/app.css` e `public/stocks.css`.

Depois de alterar o código, execute `npm.cmd run build` para regenerar o HTML portátil e o índice. Edite a estrutura em `index.template.html` e `stock-section.html`. Execute `npm.cmd test` para verificar os cálculos e validações. O servidor aceita apenas conexões locais. Para publicar na internet, é necessária adaptação de hospedagem e proteção do serviço de cotações.

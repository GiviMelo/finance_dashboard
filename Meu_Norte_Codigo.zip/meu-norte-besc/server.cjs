'use strict';
// Servidor exclusivamente local. A chave nunca é enviada ao navegador.
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
if(fs.existsSync(path.join(__dirname,'.env')))process.loadEnvFile(path.join(__dirname,'.env'));
const Core=require('./public/stock-core.js');
const PORT=Number(process.env.PORT||3000);
const token=process.env.BRAPI_API_KEY||'';
const demo=new Set(['PETR4','VALE3','ITUB4','MGLU3']);
const publicFiles=new Set(['index.html','app.css','base.js','stocks.css','stocks.js','stock-core.js','Meu_Norte_Investimentos.html']);
const cache=new Map();
let queue=Promise.resolve();
function serialized(fn){const task=queue.then(fn,fn);queue=task.catch(()=>{});return task;}
function send(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));}
async function quote(ticker){
  if(!token&&!demo.has(ticker))throw Error('Configure BRAPI_API_KEY para este ativo.');
  const cached=cache.get(ticker);if(cached&&Date.now()-cached.at<15*60*1000)return cached.value;
  return serialized(async()=>{
    const again=cache.get(ticker);if(again&&Date.now()-again.at<15*60*1000)return again.value;
    const response=await fetch('https://brapi.dev/api/v2/stocks/quote?symbols='+encodeURIComponent(ticker),{
      headers:token?{Authorization:'Bearer '+token}:{},signal:AbortSignal.timeout(15000),redirect:'error'
    });
    if(!response.ok)throw Error(response.status===429?'Limite da API atingido. Tente mais tarde.':[401,403].includes(response.status)?'Chave ou plano da API não permite esta consulta.':'Provedor indisponível ou ativo não encontrado (HTTP '+response.status+').');
    const body=await response.json();
    const result=body.results?.find(r=>(r.requestedSymbol||r.symbol)===ticker);
    const value={ticker,...Core.parseQuote(result,ticker)};
    cache.set(ticker,{at:Date.now(),value});return value;
  });
}
const server=http.createServer(async(req,res)=>{
  const allowedHosts=new Set(['localhost:'+PORT,'127.0.0.1:'+PORT]);
  if(!allowedHosts.has(req.headers.host)){res.writeHead(403);return res.end('Host não permitido.');}
  if(req.method!=='GET'){res.writeHead(405);return res.end();}
  const u=new URL(req.url,'http://localhost:'+PORT);
  if(u.pathname.startsWith('/api/')){
    if(req.headers.origin&&!['http://localhost:'+PORT,'http://127.0.0.1:'+PORT].includes(req.headers.origin))return send(res,403,{error:'Origem não permitida.'});
    if(req.headers['sec-fetch-site']==='cross-site')return send(res,403,{error:'Origem não permitida.'});
    if(u.pathname==='/api/status')return send(res,200,{service:'meu-norte',configured:!!token});
    if(u.pathname!=='/api/quotes')return send(res,404,{error:'Rota inexistente.'});
    const tickers=[...new Set((u.searchParams.get('symbols')||'').split(','))];
    if(tickers.length>200||!tickers.every(t=>/^[A-Z]{4}\d{1,2}$/.test(t)))return send(res,400,{error:'Tickers inválidos.'});
    const results=[],errors=[];
    for(const ticker of tickers){try{results.push(await quote(ticker));}catch(e){errors.push({ticker,message:e.name==='TimeoutError'?'Tempo de consulta excedido.':e.message});}}
    return send(res,200,{results,errors,requestedAt:new Date().toISOString()});
  }
  const name=u.pathname==='/'?'index.html':u.pathname.slice(1);
  if(!publicFiles.has(name)){res.writeHead(404);return res.end('Arquivo não encontrado.');}
  try{
    const type=name.endsWith('.css')?'text/css':name.endsWith('.js')?'text/javascript':'text/html';
    res.writeHead(200,{'Content-Type':type+'; charset=utf-8','X-Content-Type-Options':'nosniff','Cache-Control':'no-store'});
    res.end(fs.readFileSync(path.join(__dirname,'public',name)));
  }catch{res.writeHead(500);res.end('Execute npm run build para gerar o painel.');}
});
if(require.main===module)server.listen(PORT,'127.0.0.1',()=>console.log('Meu Norte: http://localhost:'+PORT+'\nCotações: '+(token?'chave configurada':'sem chave: apenas ativos de demonstração')+'\nMantenha este terminal aberto. Ctrl+C encerra o servidor.'));
module.exports={server,quote};

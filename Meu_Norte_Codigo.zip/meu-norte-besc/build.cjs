const fs=require('node:fs');
const path=require('node:path');
const read=name=>fs.readFileSync(path.join(__dirname,name),'utf8');
const template=read('index.template.html').replace('<!-- STOCK_SECTION -->',()=>read('stock-section.html'));
const portable=template.replace('<!-- PORTABLE_TEMPLATE -->','').replace(/<link rel="stylesheet" href="([^"]+)">/g,(_,file)=>'<style>'+read('public/'+file)+'</style>').replace(/<script src="([^"]+)"><\/script>/g,(_,file)=>'<script>'+read('public/'+file)+'</script>');
fs.writeFileSync(path.join(__dirname,'public/Meu_Norte_Investimentos.html'),portable);
const embedded='<script id="portable-template" type="text/plain">'+Buffer.from(portable).toString('base64')+'</script>';
fs.writeFileSync(path.join(__dirname,'public/index.html'),template.replace('<!-- PORTABLE_TEMPLATE -->',()=>embedded));
console.log('Gerados public/index.html e public/Meu_Norte_Investimentos.html');
